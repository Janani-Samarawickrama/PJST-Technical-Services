<?php
include_once 'database.php';
if(isset($_POST['submit']))
{	 
	 print_r($_POST);
	 $employee_id = $_POST['employee_id'];
	 $first_name = $_POST['first_name'];
	 $last_name = $_POST['last_name'];
	 $email = $_POST['email'];
	 $contact_no = $_POST['contact_no'];
	 $address = $_POST['address'];
	 $username = $_POST['username'];
	 $password = $_POST['password'];
	 $confirm_password = $_POST['confirm_password'];
	 $date_joined = date['yyyy-mm-dd'];
	
	 $sql = "INSERT INTO employee (employee_id,first_name,last_name,email,contact_no,address,username,password,confirm_password,date_joined)
	 VALUES ('$employee_id','$first_name','$last_name','$email','$contact_no','$address','$username','$password','$confirm_password','$date_joined')";
	if (mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

