<html>
<head>
<title> login </title>
<link rel ="stylesheet" type="text/css" href="Login.css">
</head>
<body bgcolor="#8080ff">
<form action="action_page.php" method="post">
  
  <div class="container">
   <center> <h1>Log In</h1> 
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>
    <br>  <br>
    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
     <br>  
	 <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
	<br><br>
    <button type="submit" class="login">Log In</button> 
	
	<button type="reset" class="cancel">Cancel</button>
	<br> <br>
	 <span class="psw">Forgot <a href="#">password?</a></span>
	
	<br><br>
	
	<button onclick="document.location='signup.html'" class="signin">Create New Account</button>
	
	<br>  <br>
    </center>
  </div>
<br> <br>
  
</form>

<?php
$servername='localhost';
$username='root';
$password='';
$dbname = "Details";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}
?>

<?php
if(isset($_POST['save']))
{	 
	 $Username = $_POST['uname'];
	 $Password = $_POST['psw'];
	
	 $sql = "INSERT INTO login (uname,psw)
	 VALUES ('$Username','$Password')";
	 if (mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>
</body>
</html>